def stripe_stub():
    return {'ok':True}
