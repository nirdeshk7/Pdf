Features: OCR (eng/hin/ara), Stripe+Razorpay hooks, Sandbox runner stub.
