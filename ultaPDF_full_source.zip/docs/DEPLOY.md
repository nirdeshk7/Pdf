Deployment steps: install binaries, set env, docker-compose up.
